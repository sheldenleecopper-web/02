-- 渝境智旅 数据库初始化脚本
-- 执行：mysql -u root -p yujing < schema.sql
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS yujing DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE yujing;

-- 用户表
CREATE TABLE IF NOT EXISTS `user` (
  `id`          BIGINT PRIMARY KEY AUTO_INCREMENT,
  `username`    VARCHAR(64)  NOT NULL UNIQUE COMMENT '用户名',
  `password`    VARCHAR(128) NOT NULL COMMENT 'BCrypt 密文',
  `role`        VARCHAR(16)  NOT NULL DEFAULT 'USER' COMMENT 'USER / ADMIN',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 去处表（景点 / 美食 / 活动）
CREATE TABLE IF NOT EXISTS `spot` (
  `id`         BIGINT PRIMARY KEY AUTO_INCREMENT,
  `name`       VARCHAR(128)   NOT NULL,
  `type`       VARCHAR(32)    COMMENT 'attraction / food / activity',
  `region`     VARCHAR(64)    COMMENT '所属区县',
  `tags`       VARCHAR(255)  COMMENT '逗号分隔标签',
  `cover`      VARCHAR(512)   COMMENT '封面图 URL',
  `intro`      TEXT,
  `heat_index` INT            DEFAULT 0 COMMENT '热度',
  `avg_cost`   DECIMAL(10,2)  COMMENT '人均消费',
  `open_time`  VARCHAR(128),
  `address`    VARCHAR(255),
  `lng`        DECIMAL(10,6),
  `lat`        DECIMAL(10,6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 非遗表
CREATE TABLE IF NOT EXISTS `heritage` (
  `id`              BIGINT PRIMARY KEY AUTO_INCREMENT,
  `name`            VARCHAR(128) NOT NULL,
  `level`           VARCHAR(32)  COMMENT '国家级 / 市级',
  `category`        VARCHAR(64),
  `cover`           VARCHAR(512),
  `intro`           TEXT,
  `inheritor`       VARCHAR(128) COMMENT '传承人',
  `experience_spot` VARCHAR(255) COMMENT '体验地点',
  `related_spot_id` BIGINT       COMMENT '关联去处 ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 酒店表
CREATE TABLE IF NOT EXISTS `hotel` (
  `id`          BIGINT PRIMARY KEY AUTO_INCREMENT,
  `name`        VARCHAR(128) NOT NULL,
  `region`      VARCHAR(64),
  `price_range` VARCHAR(32)  COMMENT '经济 / 适中 / 豪华',
  `intro`       TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 攻略表
CREATE TABLE IF NOT EXISTS `guide` (
  `id`               BIGINT PRIMARY KEY AUTO_INCREMENT,
  `user_id`          BIGINT,
  `title`            VARCHAR(255),
  `params_summary`   VARCHAR(512) COMMENT '生成参数摘要',
  `spot_ids`         VARCHAR(512) COMMENT '关联去处 ID，逗号分隔',
  `markdown_content` LONGTEXT,
  `poster_url`       VARCHAR(512),
  `is_saved`         TINYINT      DEFAULT 0 COMMENT '0 未保存 1 已保存',
  `create_time`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_guide_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 收藏表
CREATE TABLE IF NOT EXISTS `favorite` (
  `id`          BIGINT PRIMARY KEY AUTO_INCREMENT,
  `user_id`    BIGINT  NOT NULL,
  `spot_id`    BIGINT  NOT NULL,
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_user_spot` (`user_id`, `spot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 浏览历史表
CREATE TABLE IF NOT EXISTS `browse_history` (
  `id`          BIGINT PRIMARY KEY AUTO_INCREMENT,
  `user_id`    BIGINT  NOT NULL,
  `spot_id`    BIGINT  NOT NULL,
  `browse_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_history_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 初始管理员账号：admin / admin123（BCrypt 密文）
INSERT INTO `user` (`username`, `password`, `role`) VALUES
('admin', '$2a$10$sQ6Hm2igH7aVabyLm8NrFOQtJS60Wc3los261xokVdqJN7Mm5nHve', 'ADMIN')
ON DUPLICATE KEY UPDATE `password` = VALUES(`password`), `role` = 'ADMIN';

-- ==================== 示例数据 ====================

INSERT INTO `spot` (`name`, `type`, `region`, `tags`, `cover`, `intro`, `heat_index`, `avg_cost`, `open_time`, `address`, `lng`, `lat`) VALUES
('洪崖洞', 'attraction', '渝中区', '夜景,吊脚楼,打卡', '', '依山而建的巴渝传统吊脚楼群，夜晚灯火通明，是重庆最具代表性的地标之一。', 98, 0.00, '全天开放', '重庆市渝中区嘉陵江滨江路88号', 106.583, 29.564),
('解放碑', 'attraction', '渝中区', '地标,商圈,历史', '', '抗战胜利纪功碑，重庆城市原点，周边是全国著名商圈。', 95, 0.00, '全天开放', '重庆市渝中区民权路', 106.576, 29.560),
('磁器口古镇', 'attraction', '沙坪坝区', '古镇,小吃,老街', '', '嘉陵江畔的千年古镇，青石板路与老茶馆，是体验老重庆市井生活的去处。', 92, 30.00, '全天开放', '重庆市沙坪坝区磁器口南街', 106.449, 29.582),
('长江索道', 'attraction', '渝中区', '交通,观景,老重庆', '', '横跨长江的空中客运索道，被称为"空中公交车"，可俯瞰两江交汇。', 90, 30.00, '07:30-22:30', '重庆市渝中区新华路151号', 106.588, 29.562),
('武隆天生三桥', 'attraction', '武隆区', '自然,喀斯特,世界遗产', '', '世界自然遗产，三座天生石桥气势磅礴，是《变形金刚4》取景地。', 88, 135.00, '08:30-17:00', '重庆市武隆区仙女山镇', 107.933, 29.432),
('大足石刻', 'attraction', '大足区', '世界遗产,石刻,佛教', '', '世界文化遗产，唐宋时期摩崖石刻造像群，造像精美绝伦。', 86, 115.00, '08:30-18:00', '重庆市大足区龙岗镇', 105.706, 29.703),
('重庆火锅', 'food', '渝中区', '美食,麻辣,必吃', '', '以牛油锅底、麻辣鲜香著称，重庆的城市名片。推荐老灶火锅与九宫格。', 99, 90.00, '10:00-次日02:00', '重庆市渝中区各火锅店', 106.576, 29.560),
('重庆小面', 'food', '渝中区', '美食,早餐,平价', '', '麻辣鲜香的重庆特色早餐面食，一碗小面开启山城的一天。', 94, 12.00, '06:30-14:00', '重庆市渝中区大街小巷', 106.576, 29.560),
('酸辣粉', 'food', '渝中区', '美食,小吃,街边', '', '红油酸辣粉，粉条劲道，配料丰富，是解放碑一带的经典小吃。', 85, 10.00, '09:00-22:00', '重庆市渝中区八一路好吃街', 106.576, 29.560),
('两江游轮夜游', 'activity', '渝中区', '夜景,游船,两江', '', '夜游长江与嘉陵江，观赏两岸灯火与跨江大桥，约60分钟航程。', 91, 128.00, '19:00-22:00', '重庆市渝中区朝天门码头', 106.589, 29.571),
('川剧变脸体验', 'activity', '渝中区', '非遗,演出,体验', '', '在茶馆观看川剧变脸、吐火等绝技，感受巴蜀传统戏曲魅力。', 87, 80.00, '19:30-21:30', '重庆市渝中区洪崖洞巴渝剧院', 106.583, 29.564),
('南山一棵树观景', 'activity', '南岸区', '夜景,观景台,摄影', '', '俯瞰渝中半岛夜景的最佳位置，可拍到渝中半岛全景。', 89, 30.00, '09:00-22:30', '重庆市南岸区南山植物园旁', 106.601, 29.549);

INSERT INTO `heritage` (`name`, `level`, `category`, `cover`, `intro`, `inheritor`, `experience_spot`, `related_spot_id`) VALUES
('川剧', '国家级', '传统戏剧', '', '中国西南地区代表性剧种，以变脸、吐火、滚灯等绝技闻名，唱腔高亢激越。', '沈铁梅', '洪崖洞巴渝剧院', 11),
('重庆火锅传统制作技艺', '市级', '传统技艺', '', '牛油熬制、底料炒制、九宫格分格的独特技艺，承载重庆码头文化。', '王刚', '渝中区各老字号火锅店', 7),
('蜀绣', '国家级', '传统美术', '', '中国四大名绣之一，针法严谨、色彩明快，题材多为花鸟鱼虫。', '郝淑萍', '磁器口古镇绣坊', 3),
('木洞山歌', '国家级', '传统音乐', '', '巴南区木洞镇流传的山歌，高亢悠扬，被称为"巴渝文化的活化石"。', '潘中明', '巴南区木洞镇', NULL),
('梁平竹帘', '国家级', '传统美术', '', '以慈竹为原料手工编织的竹帘画，工艺精细，可书写绘画。', '牟秉衡', '梁平区竹帘厂', NULL),
('秀山花灯', '国家级', '传统舞蹈', '', '集歌、舞、戏于一体的民间灯舞，春节闹灯习俗流传数百年。', '杨正斌', '秀山县花灯广场', NULL);

INSERT INTO `hotel` (`name`, `region`, `price_range`, `intro`) VALUES
('洪崖洞大酒店', '渝中区', '豪华', '紧邻洪崖洞，房间可俯瞰嘉陵江夜景，步行可达解放碑。'),
('解放碑威斯汀酒店', '渝中区', '豪华', '位于解放碑商圈核心，高层客房可观赏城市全景，配套齐全。'),
('磁器口古镇客栈', '沙坪坝区', '经济', '古镇内特色客栈，青砖小院，性价比高，出门即是老街。'),
('南滨路江景酒店', '南岸区', '适中', '南滨路沿线，正对渝中半岛，夜景房视野开阔。'),
('观音桥商务酒店', '江北区', '经济', '观音桥商圈，地铁直达，周边餐饮购物便利，适合年轻旅客。'),
('武隆仙女山度假酒店', '武隆区', '适中', '靠近天生三桥景区，环境清幽，适合自驾与亲子出游。');
